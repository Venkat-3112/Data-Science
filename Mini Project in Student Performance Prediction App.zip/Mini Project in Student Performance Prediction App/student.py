import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import shap
df=pd.read_csv(r'D:\DS  Project\StudentsPerformance.csv')#load Data
le_parent=LabelEncoder()#lableencoder
le_parent.fit(df['parental level of education'])
# preprocess And Encode data
def preprocess_data(df):
  data=df.copy()
  data['parental_education']=le_parent.transform(data['parental level of education'])
  data['lunch']=data['lunch'].map({'standard':0,'free/reduced':1})
#Feauture Data
  rng=np.random.RandomState(42)
  data['Study_Hours']=np.clip(rng.normal(loc=4.5,scale=2,size=len(data)),0,10)
  data['attendance_percentage']=np.clip(rng.normal(loc=70,scale=10,size=len(data)),50,100)
#feauture target
  data['Avg_score']=data[['math score','reading score','writing score']].mean(axis=1)
  x=data[['Study_Hours','attendance_percentage','parental_education','lunch']]
  y=data['Avg_score']
  return x,y,data
#train Models
def train_models(x,y):
  x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)
  lr=LinearRegression()#LinearREgression Model
  lr.fit(x_train,y_train)
  rf=RandomForestRegressor()#RandomForest Regressor Model
  rf.fit(x_train,y_train)
  return lr,rf,(x_train,x_test,y_train,y_test)
# UI Field
def main():#main Function
  st.title('Student Performance Prediction')
  x,y,data=preprocess_data(df)
  lr,rf,train_data=train_models(x,y)
  x_train,x_test,y_train,y_test=train_data
  Model_choice=st.sidebar.selectbox('Select Model',('Linear Regression','Random Forest'))
  #Input Fields
  Study_Hours = st.number_input('Study Hours:', min_value=0, max_value=10, value=4, step=1)
  Attendance_percentage = st.number_input('Attendance Percentage%:', min_value=10, max_value=100, value=10, step=1)
  parental_education_cat=st.selectbox('Parental Education Level:',df['parental level of education'].unique())
  lunch_cat=st.selectbox("Lunch type", ["standard", "free/reduced"])
  # Map Inputs
  lunch_enc=0 if lunch_cat =='standard' else 1
  parent_enc = le_parent.transform([parental_education_cat])
  # Extract scalar if variable is an array
  lunch_enc_val = lunch_enc[0] if hasattr(lunch_enc, '__getitem__') else lunch_enc
  parent_enc_val = parent_enc[0] if hasattr(parent_enc, '__getitem__') else parent_enc
# Construct 2D numpy array with scalar values
  x_input = np.array([[Study_Hours, Attendance_percentage, lunch_enc_val, parent_enc_val]])
  model=rf if Model_choice=='Random Forest' else lr
  # Plot: prediction vs dataset mean
  if st.button("Predict",type='primary'):
    st.subheader('🔍Prediction vs Dataset mean')
    pred=model.predict(x_input)[0]
    mean_score = y.mean()
    fig, ax = plt.subplots()
    ax.bar(["Prediction", "Dataset mean"], [pred, mean_score])
    ax.set_ylim(0,100)
    ax.set_title("Prediction vs dataset mean")
    ax.set_ylabel("Score")
    st.pyplot(fig)
    st.write(f"Predicted average score: **{pred:.2f}**")
    #SHAP Feature Contribution
    if Model_choice == "Random Forest":
      st.subheader("🔍 SHAP Feature Contribution")
      explainer = shap.TreeExplainer(rf,x_train)
      shap_values = explainer.shap_values(x_test)
      vals = shap_values[0] 
      feature_names = ["Study_Hour", "attendance_per", "parental_edu", "lunch"]
      order = np.argsort(np.abs(vals))[::-1]
      fig2, ax2 = plt.subplots()
      ax2.bar([feature_names[i] for i in order], vals[order])
      ax2.set_title(" SHAP Features in Random Forest")
      ax2.set_ylabel("SHAP value")
      ax2.set_xlabel("Feature Names ")
      st.pyplot(fig2)
    else:
      st.subheader("🔍 SHAP Feature Contribution")
      explainer = shap.LinearExplainer(lr, x_train)
      shap_values = explainer.shap_values(x_test)
      vals = shap_values[0]
      feature_names = ["Study_Hour", "attendance_per", "parental_edu", "lunch"]
      order = np.argsort(np.abs(vals))[::-1]
      fig1, ax1 = plt.subplots()
      ax1.bar([feature_names[i] for i in order], vals[order])
      ax1.set_title("SHAP Feature in Linear Regression")
      ax1.set_ylabel("SHAP value")
      ax1.set_xlabel("Feature Names ")
      st.pyplot(fig1)
if __name__=="__main__":
  main()




